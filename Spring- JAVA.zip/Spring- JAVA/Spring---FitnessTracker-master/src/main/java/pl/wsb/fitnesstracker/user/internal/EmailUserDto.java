package pl.wsb.fitnesstracker.user.internal;

import jakarta.annotation.Nullable;

record EmailUserDto(@Nullable Long id, String email) {

}
